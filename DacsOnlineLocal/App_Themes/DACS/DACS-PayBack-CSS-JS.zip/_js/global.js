/* ============================================================
    Add .last-child/.first-child class to columns
============================================================ */
(function() {
    $(':first-child').addClass('first-child');
    $(':last-child').addClass('last-child');
})();


/* ============================================================
    Scroll to top
============================================================ */
(function() {
    $('a[href=#top]').click(function(){
        $('html, body').animate({scrollTop:0}, 'slow');
        return false;
    });
})();


/* ============================================================
    Don't scroll to top of page when clicing tooltips
============================================================ */
(function() {
    $('a.tip').click(function(){
        return false;
    });
})();


/* ============================================================
    Toggle search result details
============================================================ */
(function() {
    $('ol.results > li').prepend('<a href="#" class="toggle">&#9658;</a>');
    $('ol.results a.toggle').toggle(function() {
        $(this).html('&#9660;');
        $(this).siblings('.details').show();
    }, function() {
        $(this).html('&#9658;');
        $(this).siblings('.details').hide();
    });
})();


/* ============================================================
   Add container around iframe embeds to enable CSS fix.
   http://webdesignerwall.com/tutorials/css-elastic-videos
============================================================ */
(function() {
    $("iframe[src*='http://youtube.com']").wrap("<div class='object youtube'></div>");
})();


/* ============================================================
    Add date picker UI to input.date
============================================================ */
(function() {
    $("input.date").datepicker({
        firstDay:1,
        dateFormat:'d MM yy'
    });
})();


/* ============================================================
   Navigation menu
============================================================ */
//(function() {
//    var $banner = $('.banner'),
//        $menu = $('.global-navigation'),
//        $search = $('.global-search');

//    $('.banner form.global-search').before('<ul class="toggle-navigation"><li class="toggle-menu"><a href="#">Main Menu</a></li><li class="toggle-search"><a href="#">Search</a></li></ul>');
//    $('.banner p.title').after('<ul class="toggle-navigation"><li class="toggle-menu"><a href="#">Main Menu</a></li></ul>');

//    //$menu.addClass('hide');
//    $('li.toggle-menu a').on('click', function() {
//        $banner.toggleClass('show-menu');
//        $banner.removeClass('show-search');
//        return false;
//    });

//    //$search.addClass('hide');
//    $('li.toggle-search a').on('click', function() {
//        $banner.toggleClass('show-search');
//        $banner.removeClass('show-menu');
//        return false;
//    });
//})();


/* ============================================================
    Reveal lightbox
============================================================ */
(function() {
    $('.show-modal').click(function() {
        $('.lightbox').show();
        return false;
    });

    $('.hide-modal').click(function() {
        $('.lightbox').hide();
        return false;
    });
})();